document.addEventListener("DOMContentLoaded", function () {
    const gameContainer = document.getElementById("game-container");
    const timerElement = document.getElementById("time");
    const reiniciarButton = document.getElementById("reiniciar");
    const modoBoton = document.getElementById("modoBoton");

    let firstNumbers = shuffle(Array.from({ length: 25 }, (_, index) => index + 1));
    let secondNumbers = shuffle(Array.from({ length: 25 }, (_, index) => index + 26));
    let numbers = firstNumbers.concat(secondNumbers);
    let shownNumbers = [];
    let nextNumberToClick = 1;
    let temporizador = 0;
    let timerInterval;
    let gameStarted = false;

    /* Tablero */
    for (let i = 0; i < 5; i++) {
        const row = document.createElement("div");
        row.className = "row";
        for (let j = 0; j < 5; j++) {
            const block = document.createElement("div");
            block.className = "block";
            block.innerText = numbers[i * 5 + j];
            block.addEventListener("click", handleClick);
            row.appendChild(block);

            // Si el bloque contiene el número 1, inicia el juego
            if (numbers[i * 5 + j] === 1) {
                block.addEventListener("click", iniciarJuego);
            }
        }
        gameContainer.appendChild(row);
    }

    /* Inicio del juego */
    function iniciarJuego() {
        gameStarted = true;
        this.removeEventListener("click", iniciarJuego);
        timerInterval = setInterval(function () {
            temporizador += 10;
            mostrarTiempo(temporizador);
        }, 10);
    }

    function handleClick() {
        if (gameStarted) {
            const clickedNumber = parseInt(this.innerText);

            if (clickedNumber === nextNumberToClick) {
                shownNumbers.push(clickedNumber);

                if (clickedNumber === 50) {
                    clearInterval(timerInterval);
                    const tiempoTranscurrido = mostrarTiempo(temporizador);
                    alert(`¡Completado en ${tiempoTranscurrido}! ¡Has ganado!`);
                    reiniciarButton.disabled = false;
                } else {
                    assignRandomNumber(this);
                    nextNumberToClick++;
                }
            }
        }
    }

    /* Cambiar numeros */
    function assignRandomNumber(block) {
        let availableNumbers = numbers.filter(num => !shownNumbers.includes(num));

        // Comprobación de numeros que ya han salido 
        const shownNumbersInGrid = Array.from(gameContainer.getElementsByClassName("block"))
            .map(block => parseInt(block.innerText))
            .filter(num => !isNaN(num));

        availableNumbers = availableNumbers.filter(num => !shownNumbersInGrid.includes(num));

        if (availableNumbers.length > 0) {
            const randomIndex = Math.floor(Math.random() * availableNumbers.length);
            block.innerText = availableNumbers[randomIndex];
        } else {
            block.innerText = "";
            block.style.backgroundColor = "#fff";
        }
    }

    /* Reiniciar la partida */
    window.reiniciarContador = function () {
        clearInterval(timerInterval);
        temporizador = 0;
        mostrarTiempo(temporizador);
        gameStarted = false;
        shownNumbers = [];
        nextNumberToClick = 1;

        const firstNumbers = shuffle(Array.from({ length: 25 }, (_, index) => index + 1));
        const secondNumbers = shuffle(Array.from({ length: 25 }, (_, index) => index + 26));
        const shuffledNumbers = firstNumbers.concat(secondNumbers);

        reiniciarButton.disabled = false;

        /* Asegurar el reinicio */
        gameContainer.innerHTML = '';

        /* Tablero */
        for (let i = 0; i < 5; i++) {
            const row = document.createElement("div");
            row.className = "row";
            for (let j = 0; j < 5; j++) {
                const block = document.createElement("div");
                block.className = "block";
                block.addEventListener("click", handleClick);
                row.appendChild(block);

                const number = shuffledNumbers[i * 5 + j];
                block.innerText = number;

                if (number === 1) {
                    block.addEventListener("click", iniciarJuego);
                }
            }
            gameContainer.appendChild(row);
        }
    }

    /* Modo oscuro */
    modoBoton.addEventListener("click", function () {
        document.body.classList.toggle("modo-oscuro");
    });
    
    /* Cambiar tiempo */
    function mostrarTiempo(tiempo) {
        const segundos = Math.floor(tiempo / 1000);
        const milisegundos = tiempo % 1000;
        const milisegundosFormateados = milisegundos.toFixed(0).padStart(3, '0');
        const tiempoTranscurrido = `${segundos}.${milisegundosFormateados}s`;
        timerElement.innerText = tiempoTranscurrido;
        return tiempoTranscurrido;
    }

    /* Mezclar numeros */ 
    function shuffle(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
});